/*
 *  Change_A_Vehicle__Speed_Button.java
 *  Kevin Aka
 *  12-20-23
 *
 *  CS 86 Homework 7
 * 
 *  This file creates the the Change_A_Vehicle_Speed_Button 
 *  .
 * 
 */
import javax.swing.JButton;

public class Change_A_Vehicle_Speed_Button extends JButton{
    
}
