/*
 *  Start_Buses_Button.java
 *  Kevin Aka
 *  12-20-23
 *
 *  CS 86 Homework 7
 * 
 *  This file shows the steps the program takes to create the Start Buses Button
 * 
 */

import javax.swing.JButton;

public class Start_Buses_Button extends JButton {
    
}
