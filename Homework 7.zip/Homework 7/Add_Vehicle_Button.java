/*
 *  Add_Vehicle_Button.java
 *  Kevin Aka
 *  12-20-23
 *
 *  CS 86 Homework 7
 * 
 *  This file creates the the Add_Vehicle_Button 
 *  .
 * 
 */
import javax.swing.JButton;

public class Add_Vehicle_Button extends JButton{
    
}
