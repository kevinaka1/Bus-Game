/*
 *  Change_Color_Button.java
 *  Kevin Aka
 *  12-20-23
 *
 *  CS 86 Homework 7
 * 
 *  This file creates the the Change_Color_Button 
 *  .
 * 
 */
import javax.swing.JButton;

public class Change_Color_Button extends JButton{
    
}
