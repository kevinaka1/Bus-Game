/*
 *  Main.java
 *  Kevin Aka
 *  12-20-23
 *
 *  CS 86 Homework 7
 * 
 *  This file tells the program to start the Tufts Shuttle
 *  Tracker simuation
 * 
 */

public class Main{
    public static void main(String[] args){
		new Main();
	}

	public Main(){
		Start_Tufts_Shuttle_Tracker tufts_shuttle_tracker = new Start_Tufts_Shuttle_Tracker();
	}
	
}