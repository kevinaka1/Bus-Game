/*
 *  Zoom_Button.java
 *  Kevin Aka
 *  12-20-23
 *
 *  CS 86 Homework 7
 * 
 *  This file shows the steps the program takes to create a Zoom_Button
 * 
 */

import javax.swing.JButton;

public class Zoom_Button extends JButton {
    
}
